from typing import Tuple, Dict
import torch
from torch import nn
import numpy as np

from ..config import Config


class EstPoseNet(nn.Module):

    config: Config

    def __init__(self, config: Config):
        """
        Directly estimate the translation vector and rotation matrix.
        """
        super().__init__()
        self.config = config
        self.MLP1 = nn.Sequential(
            nn.Conv1d(in_channels=3, out_channels=64, kernel_size=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Conv1d(in_channels=64, out_channels=128, kernel_size=1),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Conv1d(in_channels=128, out_channels=1024, kernel_size=1),
            nn.BatchNorm1d(1024),
            nn.ReLU()
        )
        self.maxpool = nn.MaxPool1d(kernel_size=1024)
        # MLP for processing the global feature vector
        self.MLP2T = nn.Sequential(
            nn.Linear(1024,512),
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Linear(512,256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Linear(256,3)
        )
        self.MLP2R = nn.Sequential(
            nn.Linear(1024,512),
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Linear(512,256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Linear(256,6)
        )

        self.L2 = nn.MSELoss()

    def compute_rotation_matrix_from_6d(self, poses_6d: torch.Tensor):
        """
        Converts a 6D representation to a rotation matrix.
        This is the key function for both training and testing.
        Args:
            poses_6d: (B, 6) tensor from your model's output.
        Returns:
            A (B, 3, 3) rotation matrix tensor.
        """
        # Split the 6D pose into two 3D vectors
        x_raw = poses_6d[:, 0:3]
        y_raw = poses_6d[:, 3:6]

        # Use Gram-Schmidt to make them orthogonal
        x = nn.functional.normalize(x_raw, p=2, dim=1)
        
        y_proj_x = torch.sum(x * y_raw, dim=1, keepdim=True) * x
        y = nn.functional.normalize(y_raw - y_proj_x, p=2, dim=1)
        
        # Get the third vector with a cross product
        z = torch.cross(x, y, dim=1)
        
        # Stack them into a 3x3 matrix
        R = torch.stack((x, y, z), dim=-1)
        
        return R

    def forward(
        self, pc: torch.Tensor, trans: torch.Tensor, rot: torch.Tensor, **kwargs
    ) -> Tuple[float, Dict[str, float]]:
        """
        Forward of EstPoseNet

        Parameters
        ----------
        pc : torch.Tensor
            Point cloud in camera frame, shape \(B, N, 3\)
        trans : torch.Tensor
            Ground truth translation vector in camera frame, shape \(B, 3\)
        rot : torch.Tensor
            Ground truth rotation matrix in camera frame, shape \(B, 3, 3\)

        Returns
        -------
        float
            The loss value according to ground truth translation and rotation
        Dict[str, float]
            A dictionary containing additional metrics you want to log
        """

        x_t, x_r = self.est(pc)
        
        r_rel = x_r @ rot.transpose(-2, -1)
        trace = r_rel.diagonal(offset=0, dim1=-2, dim2=-1).sum(-1)
        angle = torch.acos(torch.clamp((trace - 1) / 2, -1.0+1e-7, 1.0-1e-7))
        r_loss = angle.mean()

        t_loss = self.L2(x_t,trans)

        loss = t_loss + r_loss
        metric = dict(
            loss=loss,
            trans_loss=t_loss,
            rot_loss=r_loss
            # additional metrics you want to log
        )
        print((((x_t-trans).norm(dim=-1)).mean()).item())
        return loss, metric

    def est(self, pc: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Estimate translation and rotation in the camera frame

        Parameters
        ----------
        pc : torch.Tensor
            Point cloud in camera frame, shape \(B, N, 3\)

        Returns
        -------
        trans: torch.Tensor
            Estimated translation vector in camera frame, shape \(B, 3\)
        rot: torch.Tensor
            Estimated rotation matrix in camera frame, shape \(B, 3, 3\)

        Note
        ----
        The rotation matrix should satisfy the requirement of orthogonality and determinant 1.
        """
        pc = pc.transpose(2, 1)
        x = self.MLP1(pc)
        x = self.maxpool(x)
        x = x.view(x.size(0),-1)
        trans = self.MLP2T(x)
        rot = self.MLP2R(x)
        rot = self.compute_rotation_matrix_from_6d(rot)
        return trans, rot
        
