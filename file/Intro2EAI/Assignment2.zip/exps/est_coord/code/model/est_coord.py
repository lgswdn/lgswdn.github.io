from typing import Tuple, Dict
import numpy as np
import torch
from torch import nn

from ..config import Config
from ..vis import Vis


class EstCoordNet(nn.Module):

    config: Config

    def __init__(self, config: Config):
        """
        Estimate the coordinates in the object frame for each object point.
        """
        super().__init__()
        self.config = config

        self.MLP0 = nn.Conv1d(in_channels=3, out_channels=64, kernel_size=1)

        self.MLP1 = nn.Sequential(
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Conv1d(in_channels=64, out_channels=128, kernel_size=1),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Conv1d(in_channels=128, out_channels=1024, kernel_size=1),
            nn.BatchNorm1d(1024),
            nn.ReLU()
        )
        self.maxpool = nn.MaxPool1d(kernel_size=1024)
        self.MLP2 = nn.Sequential(
            nn.Conv1d(in_channels=1024+64, out_channels=512, kernel_size=1),
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Conv1d(in_channels=512, out_channels=256, kernel_size=1),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Conv1d(in_channels=256, out_channels=128, kernel_size=1),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Conv1d(in_channels=128, out_channels=3, kernel_size=1),
        )
        self.mseloss=nn.MSELoss()


    def forward(
        self, pc: torch.Tensor, coord: torch.Tensor, **kwargs
    ) -> Tuple[float, Dict[str, float]]:
        """
        Forward of EstCoordNet

        Parameters
        ----------
        pc: torch.Tensor
            Point cloud in camera frame, shape \(B, N, 3\)
        coord: torch.Tensor
            Ground truth coordinates in the object frame, shape \(B, N, 3\)

        Returns
        -------
        float
            The loss value according to ground truth coordinates
        Dict[str, float]
            A dictionary containing additional metrics you want to log
        """

        N = pc.shape[1]
        pc = pc.transpose(2,1) #B*3*N
        f1 = self.MLP0(pc) #B*64*N
        feap = self.MLP1(f1) #B*1024*N
        feag = self.maxpool(feap) #B*1024*1
        x = torch.cat([feag.expand(-1, -1, N), f1], dim=1) #B*1088*N
        pred_c = self.MLP2(x) #B*3*N

        coord = coord.transpose(2,1)
        loss = self.mseloss(pred_c,coord)
        metric = dict(
            loss=loss,
            coord=pred_c.transpose(2,1)
            # additional metrics you want to log
        )
        return loss, metric

    def est(self, pc: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Estimate translation and rotation in the camera frame

        Parameters
        ----------
        pc : torch.Tensor
            Point cloud in camera frame, shape \(B, N, 3\)

        Returns
        -------
        trans: torch.Tensor
            Estimated translation vector in camera frame, shape \(B, 3\)
        rot: torch.Tensor
            Estimated rotation matrix in camera frame, shape \(B, 3, 3\)

        Note
        ----
        The rotation matrix should satisfy the requirement of orthogonality and determinant 1.

        We don't have a strict limit on the running time, so you can use for loops and numpy instead of batch processing and torch.

        The only requirement is that the input and output should be torch tensors on the same device and with the same dtype.
        """
        N = pc.shape[1]
        loss, metric = self.foward(pc, pc)
        p_coord = metric['coord']
        m_coord = torch.mean(pred,dim=1)
        m_cam = torch.mean(pc,dim=1)
        n_coord = pred - m_coord.expand(-1,N,1)
        n_cam = pc - m_cam.expand(-1,N,1)
        # n_coord & n_cam : (B,N,3)
        mtn = n_coord.transpose(2,1) @ n_cam
        U, S, Vt = np.linalg.SVD(mtn)
        dt = np.linalg.determinant(Vt @ U)
        rot = Vt @ np.diagonal(np.array([]))